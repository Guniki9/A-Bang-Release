@echo off
chcp 65001 > nul
title A! Programming Language - Official Runtime Environment (v2.01)
cls
echo ================================================================
echo   "A!" Programming Language - Official Runtime (v2.01)
echo. ================================================================


:basla
set "komut="
set /p "komut=A!> "

if not defined komut goto basla

setlocal EnableDelayedExpansion
set "temiz=!komut!"

:: Remove trailing spaces
:bosluk_sil
if "!temiz:~-1!"==" " (
    set "temiz=!temiz:~0,-1!"
    goto bosluk_sil
)

:: 1. Full Automation Chain Check (i.i.c and xx)
echo "!temiz!" | findstr /C:"))i.i.c))xx" > nul 2>&1
if !errorlevel! equ 0 (
    echo [Focus Engine]: Entities locked via dependency bridge.
    echo [i.i.c Controller]: Step completed! Signal broadcasted.
    echo [Final Seal - xx]: Phase memory cleared. Advancing to next stage!
    echo.
    endlocal
    goto basla
)

:: 2. Standalone xx Check
if "!temiz!"=="xx" (
    echo [Final Seal - xx]: Scene memory flushed. Advancing to next level!
    echo.
    endlocal
    goto basla
)

:: 3. Strict 'x' Seal Check
if not "!temiz:~-1!"=="x" (
    color 0C
    echo [A! Compile Error]: Missing 'x' protection seal at line end!
    echo ^> Execution rejected to prevent processor crash.
    echo.
    color 0F
    endlocal
    goto basla
)

:: 4. Successful Execution Output
echo [Processor]: Step executed successfully. Focus reset.
echo.
endlocal
goto basla
